import React, { useState } from 'react';
import { Users, BookOpen, Settings, BarChart2, ChevronLeft, ChevronRight, Database, ExternalLink, TrendingUp, Car } from 'lucide-react';
import { clsx } from 'clsx';

const Sidebar = ({ activeTab, setActiveTab }) => {
    const [collapsed, setCollapsed] = useState(false);
    const [expandedMenus, setExpandedMenus] = useState({});

    const menuItems = [
        {
            icon: TrendingUp,
            label: '猜你喜欢'
        },
        {
            icon: Car,
            label: '车辆管理',
            subItems: ['在售车辆', '拍卖管理', '车辆入库']
        },
        {
            icon: Users,
            label: '成员管理',
            subItems: ['邀请成员', '授权管理']
        },
        {
            icon: BookOpen,
            label: '课程开发'
        },
        {
            icon: Settings,
            label: '课程配置',
            subItems: ['陪练场景设定', '陪练教练设定库', '答疑教练设定库', '定制训练计划']
        },
        {
            icon: BarChart2,
            label: '数据看板',
            subItems: ['数据概览', '团队成长档案']
        },
        {
            icon: Database,
            label: '系统设置',
            subItems: ['用量统计']
        },
    ];

    // Auto-expand menu if active tab is a sub-item
    React.useEffect(() => {
        const parent = menuItems.find(item => item.subItems?.includes(activeTab));
        if (parent) {
            setExpandedMenus(prev => ({ ...prev, [parent.label]: true }));
        } else if (menuItems.some(item => item.label === activeTab && item.subItems)) {
            // If activeTab matches a parent label (e.g. from "Go to Course Config"), expand it
            setExpandedMenus(prev => ({ ...prev, [activeTab]: true }));
        }
    }, [activeTab]);

    const toggleMenu = (label) => {
        setExpandedMenus(prev => ({ ...prev, [label]: !prev[label] }));
    };

    const handleItemClick = (item) => {
        if (item.subItems) {
            toggleMenu(item.label);
        } else {
            setActiveTab(item.label);
        }
    };

    return (
        <div
            className={clsx(
                "h-full bg-slate-900 flex flex-col transition-all duration-300 relative",
                collapsed ? "w-16" : "w-64"
            )}
        >
            {/* Logo Area */}
            <div className="h-16 flex items-center justify-center border-b border-slate-800">
                <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                    <Car className="text-white" size={20} />
                </div>
                {!collapsed && (
                    <span className="ml-3 text-white font-semibold text-lg">二手车拍卖</span>
                )}
            </div>

            {/* Navigation Items */}
            <div className="flex-1 py-6 space-y-2 overflow-y-auto">
                {menuItems.map((item, index) => {
                    const isActive = activeTab === item.label || item.subItems?.includes(activeTab);
                    const isExpanded = expandedMenus[item.label];

                    return (
                        <div key={index}>
                            <div
                                onClick={() => handleItemClick(item)}
                                className={clsx(
                                    "flex items-center px-4 py-3 cursor-pointer transition-colors relative",
                                    isActive && !item.subItems
                                        ? "bg-blue-600 text-white"
                                        : "text-slate-400 hover:bg-slate-800 hover:text-white"
                                )}
                            >
                                <item.icon size={20} className={clsx("flex-shrink-0", isActive && "text-white")} />
                                {!collapsed && (
                                    <>
                                        <span className="ml-3 font-medium flex-1">{item.label}</span>
                                        {item.subItems && (
                                            <ChevronRight
                                                size={16}
                                                className={clsx("transition-transform", isExpanded && "rotate-90")}
                                            />
                                        )}
                                    </>
                                )}
                            </div>

                            {/* Sub-menu */}
                            {!collapsed && item.subItems && isExpanded && (
                                <div className="bg-slate-950 py-1">
                                    {item.subItems.map((subItem, subIndex) => (
                                        <div
                                            key={subIndex}
                                            onClick={() => setActiveTab(subItem)}
                                            className={clsx(
                                                "pl-12 pr-4 py-2 text-sm cursor-pointer transition-colors",
                                                activeTab === subItem
                                                    ? "text-blue-400 bg-slate-900"
                                                    : "text-slate-500 hover:text-slate-300"
                                            )}
                                        >
                                            {subItem}
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>

            {/* Employee Side Link */}
            <div className="px-4 py-2 border-t border-slate-800">
                <div
                    onClick={() => console.log('Jump to Employee Side')}
                    className={clsx(
                        "flex items-center py-2 cursor-pointer transition-colors text-slate-400 hover:text-white"
                    )}
                >
                    <ExternalLink size={20} className="flex-shrink-0" />
                    {!collapsed && (
                        <span className="ml-3 font-medium flex-1">跳转员工端</span>
                    )}
                </div>
            </div>

            {/* Collapse Button */}
            <button
                onClick={() => setCollapsed(!collapsed)}
                className="absolute top-1/2 -right-3 transform -translate-y-1/2 p-1 bg-slate-700 hover:bg-slate-600 rounded-full text-white shadow-lg z-10"
            >
                {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
            </button>

            <div className="p-4 border-t border-slate-800">
                <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full bg-slate-700 flex items-center justify-center text-xs">
                        U
                    </div>
                    {!collapsed && (
                        <div className="ml-3 overflow-hidden">
                            <div className="text-sm font-medium truncate">User Name</div>
                            <div className="text-xs text-slate-500 truncate">Admin</div>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Sidebar;
